package com.aemcompany.myproject;

public interface SearchService {
	
	public String getResult();
	public void addProperty();
}
