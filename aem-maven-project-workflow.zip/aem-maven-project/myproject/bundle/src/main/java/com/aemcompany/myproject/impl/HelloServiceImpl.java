package com.aemcompany.myproject.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.Repository;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.Property;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.aemcompany.myproject.HelloService;
import org.apache.sling.commons.osgi.*;
import org.osgi.service.component.ComponentContext;

import com.day.cq.wcm.api.Page;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;


/**
 * One implementation of the {@link HelloService}. Note that the repository is
 * injected, not retrieved.
 */
@Component(immediate = true, metatype = true, label = "Salutation Service")
@Service
@Properties({
	@Property(name = "Label", description = "The Salutation", value = "Hello"),
	@Property(name = "sling.servlet.paths", description = "Servlet Path", value = "/bin/resource")
	})

public class HelloServiceImpl implements HelloService {

	public static final Logger LOGGER = LoggerFactory.getLogger(HelloServiceImpl.class);
	public String salutation;

	@Reference ResourceResolverFactory resolverFactory;
	@Reference private SlingRepository repository;
	

	protected void activate(ComponentContext componentContext) {
		this.salutation = PropertiesUtil.toString(componentContext.getProperties().get("Label"), null);
	}

	public String getRepositoryName() {
		LOGGER.info("Adding the repository");
		return repository.getDescriptor(Repository.REP_NAME_DESC);

	}

	public String getSalutation() {
		LOGGER.info(salutation);
		return salutation;
	}

	public String getPageTitle() {
		Map<String, Object> param = new HashMap<String, Object>();        
	    param.put(ResourceResolverFactory.SUBSERVICE, "readService");
	    ResourceResolver resourceResolver=null;
		try {
			resourceResolver = resolverFactory.getServiceResourceResolver(param);
			Resource pageResource = resourceResolver.getResource("/content/aem-company");
			Page myPage = pageResource.adaptTo(Page.class);
			String title = myPage.getTitle();
			return title;

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info("Exception:" +e);
		}
		return "null";
	}

}
