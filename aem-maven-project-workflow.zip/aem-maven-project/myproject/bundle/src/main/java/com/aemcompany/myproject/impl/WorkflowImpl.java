package com.aemcompany.myproject.impl;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;

@Component(immediate = true, metatype = true, label = "Workflow Service")
@Service
@Property(name = "process.label", value = "AEM Workflow Process")
public class WorkflowImpl implements WorkflowProcess{

	 private Logger log = LoggerFactory.getLogger(this.getClass());
	 public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap args) throws WorkflowException
	 
	 {

		WorkflowData data = workItem.getWorkflowData();
		String payload = (String)data.getPayload(); 
        log.info("From workflow.");
		log.info(payload);
	 }
	
}
