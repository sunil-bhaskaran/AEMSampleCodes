package com.aemcompany.myproject.impl;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Repository;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.observation.Event;
import javax.jcr.observation.EventIterator;
import javax.jcr.observation.EventListener;
import javax.jcr.observation.ObservationManager;
import javax.jcr.query.Row;
import javax.jcr.query.RowIterator;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.Property;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.aemcompany.myproject.HelloService;
import com.aemcompany.myproject.SearchService;

import org.apache.sling.commons.osgi.*;
import org.osgi.framework.BundleContext;
import org.osgi.service.component.ComponentContext;

import com.day.cq.wcm.api.Page;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;

@Component(immediate = true, metatype = true, label = "Search Service")
@Service

public class SearchServiceImpl implements SearchService{
	public static final Logger LOGGER = LoggerFactory.getLogger(SearchServiceImpl.class);
	@Reference ResourceResolverFactory resolverFactory;
	@Reference private SlingRepository repository;
	private BundleContext bundleContext;
	private ObservationManager observationManager;
	
	public String getResult() {
		String title;
		String author = null;
		Map<String, Object> param = new HashMap<String, Object>();        
	    param.put(ResourceResolverFactory.SUBSERVICE, "readService");
	    ResourceResolver resourceResolver=null;
		try {
			resourceResolver = resolverFactory.getServiceResourceResolver(param);
			Session session = resourceResolver.adaptTo(Session.class);
			javax.jcr.query.QueryManager queryManager = session.getWorkspace().getQueryManager();
			String sqlStatement = "SELECT * FROM [cq:PageContent] WHERE CONTAINS(author, 'Sunil')";
			javax.jcr.query.Query query = queryManager.createQuery(sqlStatement,"JCR-SQL2");
			javax.jcr.query.QueryResult result = query.execute();
			javax.jcr.NodeIterator nodeIter = result.getNodes();
		
			while ( nodeIter.hasNext() ) {
				LOGGER.info("From the search");
				javax.jcr.Node node = nodeIter.nextNode();
				title = node.getProperty("jcr:title").getString();
				author = node.getProperty("author").getString();
				
				LOGGER.info(title);
				LOGGER.info(author);
								
			}
			

			return author;
			


		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info("Exception:" +e);
		}
		return "No value";
	}
	
	public void addProperty()
	{
		Map<String, Object> param = new HashMap<String, Object>();        
	    param.put(ResourceResolverFactory.SUBSERVICE, "readService");
	    ResourceResolver resourceResolver=null;
		try {
			resourceResolver = resolverFactory.getServiceResourceResolver(param);
			Resource pageResource = resourceResolver.getResource("/content/aem-company/jcr:content");
			Node myNode = pageResource.adaptTo(Node.class);
			myNode.setProperty("author", "sunil");
			Session session = resourceResolver.adaptTo(Session.class);
			session.save();
			LOGGER.info("Added");
			

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info("Exception:" +e);
		}
	}

}
