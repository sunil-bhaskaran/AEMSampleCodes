package com.aemcompany.myproject.impl;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Repository;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.observation.Event;
import javax.jcr.observation.EventIterator;
import javax.jcr.observation.EventListener;
import javax.jcr.observation.ObservationManager;
import javax.jcr.query.Row;
import javax.jcr.query.RowIterator;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.Property;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.aemcompany.myproject.HelloService;
import com.aemcompany.myproject.SearchService;

import org.apache.sling.commons.osgi.*;
import org.osgi.framework.BundleContext;
import org.osgi.service.component.ComponentContext;

import com.day.cq.wcm.api.Page;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;

@Component(metatype=true)
@Service
public class EventManagerImpl implements Runnable, EventListener {
    
    private Logger log = LoggerFactory.getLogger(this.getClass());
    private BundleContext bundleContext;   
    @Reference
    private SlingRepository repository;
    @Reference
    private ResourceResolverFactory resolverFactory;
    private Session session;
    private ObservationManager observationManager;
    
    public void run() {
        log.info("Running...");
    }
    
    protected void activate(ComponentContext ctx) {
    this.bundleContext = ctx.getBundleContext();
        
        try
        {
                   
            session = repository.loginAdministrative(null);
            observationManager = session.getWorkspace().getObservationManager();
            observationManager.addEventListener(this, Event.NODE_ADDED, "/content", true, null, null, false);
            log.info("Listening to the event.");
                          
         }
        catch(Exception e)
        {
            e.printStackTrace(); 
         }
        }

         protected void deactivate(ComponentContext componentContext) throws RepositoryException {
             
             if(observationManager != null) {
                 observationManager.removeEventListener(this);
             }
             if (session != null) {
                 session.logout();
                 session = null;
               }
         }

        public void onEvent(EventIterator itr) {
             log.info("A new node was added to /content ");
                         
         }
}