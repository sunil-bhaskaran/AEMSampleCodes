package com.aemcompany.myproject.impl;
import java.io.IOException;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;

@SlingServlet(paths="/bin/casestudy", methods="GET")
public class ServletResponse extends SlingSafeMethodsServlet{
	private static final long serialVersionUID = 1L;
	public void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException
	{

		response.setHeader("Content-Type", "application/json");
		response.getWriter().print("Thanks for the patience. Coming soon!!");

	}

}
