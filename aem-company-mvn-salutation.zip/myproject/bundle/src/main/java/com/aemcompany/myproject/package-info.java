@Version("1.0.0")
package com.aemcompany.myproject;

import aQute.bnd.annotation.Version;