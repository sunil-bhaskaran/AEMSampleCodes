package com.aemcompany.myproject.impl;

import javax.jcr.Repository;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.Property;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.aemcompany.myproject.HelloService;

import com.day.cq.wcm.api.Page;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.osgi.*;
import org.osgi.service.component.ComponentContext;

/**
 * One implementation of the {@link HelloService}. Note that the repository is
 * injected, not retrieved.
 */
@Component(immediate = true, metatype = true, label = "Salutation Service")
@Service
@Property(name = "Label", description = "The Salutation", value = "Hello")

public class HelloServiceImpl implements HelloService {

	public static final Logger LOGGER = LoggerFactory.getLogger(HelloServiceImpl.class);
	public String salutation;

	@Reference private SlingRepository repository;
	

	protected void activate(ComponentContext componentContext) {
		this.salutation = PropertiesUtil.toString(componentContext.getProperties().get("Label"), null);
	}

	public String getRepositoryName() {
		LOGGER.info("Adding the repository");
		return repository.getDescriptor(Repository.REP_NAME_DESC);

	}

	public String getSalutation() {
		LOGGER.info(salutation);
		return salutation;
	}

}
