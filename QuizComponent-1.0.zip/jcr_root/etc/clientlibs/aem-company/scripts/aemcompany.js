function checkAnswer(form) 
{
 for (var i = 0; i < form.options.length; i++) 
	{ 
	if (form.options[i].checked)
		{
		break
		}
	}
	if (form.options[i].value == form.answer.value)
	{ 
		alert("You selected the correct answer!! :)") 
	} 
	else 
	{ 
		alert("You selected an incorrect answer!!" )     
	}
}