use(function () {


    var CONST = {
        PROP_QUESTION: "jcr:question",
        PROP_OPTIONA: "jcr:optiona",
        PROP_OPTIONB: "jcr:optionb",
        PROP_OPTIONC: "jcr:optionc",
        PROP_OPTIOND: "jcr:optiond",
        PROP_ANSWER: "jcr:answer"

    }

    var data = {};

    // The url entered in the dialog

    data.question = granite.resource.properties[CONST.PROP_QUESTION]
    data.optionA = granite.resource.properties[CONST.PROP_OPTIONA]
    data.optionB = granite.resource.properties[CONST.PROP_OPTIONB]
    data.optionC = granite.resource.properties[CONST.PROP_OPTIONC]
	data.optionD = granite.resource.properties[CONST.PROP_OPTIOND]
    data.answer	= granite.resource.properties[CONST.PROP_ANSWER]

    if (data.question ==null)
    {
		data.question = "Type the question";
    }

    if (data.optionA ==null)
    {
		data.optionA = "Type the option A";
    }

    if (data.optionB ==null)
    {
		data.optionB = "Type the option B";
    }

    if (data.optionC ==null)
    {
		data.optionC = "Type the option C";
    }

    if (data.optionD ==null)
    {
		data.optionD = "Type the option D";
    }

    // Adding the constants to the exposed API
    data.CONST = CONST;

    return data;

});