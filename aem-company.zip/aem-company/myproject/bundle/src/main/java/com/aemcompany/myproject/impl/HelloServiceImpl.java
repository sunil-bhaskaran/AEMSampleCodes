package com.aemcompany.myproject.impl;

import javax.jcr.Repository;
import java.util.Dictionary;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.jcr.api.SlingRepository;
import com.aemcompany.myproject.HelloService;
import org.apache.felix.scr.annotations.Property;
import org.osgi.service.component.ComponentContext;
import org.apache.sling.commons.osgi.OsgiUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * One implementation of the {@link HelloService}. Note that
 * the repository is injected, not retrieved.
 */
@Component(immediate = true, metatype = true, label = "Cleanup Service")
@Service(value = HelloServiceImpl.class)
@Property(name = "Label", description = "The value", value = "Hello")
	
public class HelloServiceImpl implements HelloService {

public static final String LABEL = "label";
private String label;

private static final Logger LOGGER = LoggerFactory.getLogger(HelloServiceImpl.class);
    
    @Reference
    private SlingRepository repository;

	protected void activate(ComponentContext componentContext){
    configure(componentContext.getProperties());
    }

	    protected void configure(Dictionary<?, ?> properties) {
        this.label = OsgiUtil.toString(properties.get("Label"), null);
        LOGGER.info(label);
    }
	
    public String getRepositoryName() {
        return repository.getDescriptor(Repository.REP_NAME_DESC);
    }

}
